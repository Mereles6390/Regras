// No JavaScript is strictly necessary for the core functionality
// thanks to the <details> and <summary> HTML elements.
// This file is kept for potential future enhancements.

console.log("Bem-vindo à página de regras da Nação Gamer! As regras são expansíveis.");

